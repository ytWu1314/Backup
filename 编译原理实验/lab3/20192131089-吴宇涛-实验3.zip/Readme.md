### 使用说明:

1. `demo`中的可执行程序中的.exe文件可以直接运行
2. `code`文件夹不要在有中文路径下运行，需要删除.user文件重新编译运行
3. `wenfa.txt` `1.txt `   `2.txt`  是GUI版本的测试样例
4. `savewenfa.txt` 是保存`textEdit`中的内容
5. `huajianwenfa.txt`是化简后的文法
