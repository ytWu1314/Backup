#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPainter>
#include <QGraphicsOpacityEffect>
#include <QFile>
#include <QFileDialog>
#include<QString>
#include<iostream>
#include<cstring>
#include<fstream>
#include<vector>
#include<unordered_map>
#include<QTextCodec>
#include<QLabel>
#include <QTextStream>
#include<fstream>
#include<bits/stdc++.h>
#include <QTableWidget>
#include <QTableWidgetItem>

const int N=110;
QString Path;
std::string str;
std::unordered_map<char,int> mp;//非终结符在左边是否出现
std::unordered_map<char,bool> mpr; //判断非终结符是否在右边出现

//初始输入文法的非终结符个数
int cnt=1;
int cntidx=1;
//邻接表
struct Node{
    std::string str;
    Node * next;
};
struct Head{
    char id;
    Node * link;
}head[N];
std::set<std::string> ans;
std::vector<std::string> temp;
int cntdigui;
char endstr='Z'; //新的非终结符

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setObjectName("mainWindow");
    this->setStyleSheet("#mainWindow{border-image:url(:/bianyiyuanli.png);}");
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::init()
{
    //初始化结构体
    memset(head,0,sizeof (struct Head)*N);
    ui->textEdit_2->clear();
    ui->textEdit_3->clear();
    ui->textEdit_4->clear();
    temp.clear();


    //将textEdit中的内容转化为字符串数组
    QString tempstr1=ui->textEdit->toPlainText();
    std::cout<<"****************"<<std::endl;
    std::string x1=tempstr1.toStdString();
    std::string str1[N];
    int cntstr1=0;
    for(int r=0;r<int(x1.size());r++)
    {
        if(x1[r]=='\n')
        {
            cntstr1++;
            continue;
        }
        str1[cntstr1].push_back(x1[r]);
    }
    for(int i=0;i<=cntstr1;i++)
    {
       std::cout<<str1[i]<<std::endl;
    }
    std::cout<<x1.size();
    std::cout<<std::endl<<"****************"<<std::endl;

    //文法转化为字符串
    for(int i=0;i<=cntstr1;i++)
    {
        //有害规则
        if(str1[i][0]==str1[i][3] && str1[i].size()==4)
        {
            continue;
        }
        //把输入的有效字符串存到字符串数组
        temp.push_back(str1[i][0]+str1[i].substr(3,str1[i].size()-3));

        //判断不是起始符号的非终结符是否在右边出现
        for(int j=3;j<int(str1[i].size());j++)
        {
            if(str1[i][j]>='A'&&str1[i][j]<='Z')
            mpr[str1[i][j]]=true;
        }
    }



//    std::ifstream is(Path.toStdString());
//    while(!is.eof())
//    {
//        getline(is,str);
//        os<<str<<std::endl;
//        //有害规则
//        if(str[0]==str[3] &&str.size()==4)
//        {
//            continue;
//        }
//        //把输入的有效字符串存到字符串数组
//        temp.push_back(str[0]+str.substr(3,str.size()-3));

//        //判断不是起始符号的非终结符是否在右边出现
//        for(int i=3;i<int(str.size());i++)
//        {
//            if(str[i]>='A'&&str[i]<='Z')
//            mpr[str[i]]=true;
//        }
//    }


    for(int i=0;i<int(temp.size());i++)
    {
        //遇到右边没有出现的但是不是起始符号的非终结符，不是有效文法
        if(!mpr[temp[i][0]]&&temp[i][0]!='S') continue;

        //新建一个非终结符头结点
        if(!mp[temp[i][0]])
        {
            mp[temp[i][0]]=cnt;
            head[mp[temp[i][0]]].link=NULL;
            cnt++;
        }

        //邻接表建图
        head[mp[temp[i][0]]].id=temp[i][0];
        Node *p =new Node;
        p->str=temp[i].substr(1,temp[i].size()-1);
        p->next=head[mp[temp[i][0]]].link;
        head[mp[temp[i][0]]].link=p;
    }

    //遍历输出邻接表
    for(int i=1;i<cnt;i++)
    {
        std::cout<<head[i].id;
        Node * p=head[i].link;
        while(p)
        {
            std::cout<<"->"<<p->str;
            p=p->next;
        }
        std::cout<<std::endl;
    }
    std::cout<<"cnt"<<cnt<<std::endl;
}

//深搜找出所有的有效文法
std::unordered_map<Node *,bool> visited;
void dfs(int i,Node *v, bool& flag)
{
    //cout << v->str << endl;
    if (flag) {
        return;
    }
    visited[v]=true;
    if((v->str[0]>='a' && v->str[0]<='z') || v->str[0]=='@')
    {
        flag = true;
        return;
    }
    for(int i=0;i<int(v->str.size());i++)
    {
        if(v->str[i]>='A' && v->str[i]<='Z')
        {
            int idx=mp[v->str[i]];
            Node *w=head[idx].link;
            while(w)
            {
                if(!visited[w])
                {
                    dfs(idx,w,flag);
                }
                w=w->next;
            }

        }
    }
}
//化简文法
void huajianwenfa(int cnt)
{
    for(int i=1;i<cnt;i++)
    {
        Node * p=head[i].link;
        while(p)
        {
            bool flag = false;
            visited.clear();
            dfs(i,p, flag);
            if(flag)
            {
                std::cout<<"idx"<<mp[head[i].id]<<":"<<head[i].id<<std::endl;
            }
            else {
                Node *p1=head[i].link;
                //cout<<head[i].id<<"-->"<<p->str<<endl;
                if(p1==p)
                {
                    head[i].link=p1->next;

                }
                else {
                    while(p1->next!=p) p1=p1->next;
                    p1->next=p->next;
                }
            }
            p=p->next;
        }
    }
}


void MainWindow::on_pushButton_clicked()
{
    std::ofstream outl("../huajianwenfa.txt");
    init();
    huajianwenfa(cnt);
    std::string tempstr;
    for(int i=1;i<cnt;i++)
    {
//		if(head[i].link)
//		cout<<head[i].id;
        Node * p=head[i].link;
        while(p)
        {
            outl<<head[i].id;
            outl<<"->"<<p->str<<std::endl;
            std::cout<<head[i].id;
            std::cout<<"->"<<p->str<<std::endl;
            tempstr.push_back(head[i].id);
            tempstr+="->"+p->str+"\n";
            p=p->next;
        }
    }
    QString qstr=QString::fromStdString(tempstr);
    ui->textEdit_2->setText(qstr);
}

//保存文法为文件
void MainWindow::on_pushButton_2_clicked()
{
    std::ofstream out("../savewenfa.txt");
    QString text = ui->textEdit->document()->toPlainText();
    std::string s = text.toStdString();
    out<<s;
    std::cout<<s;
    out.close();
}

//打开文法
void MainWindow::on_pushButton_3_clicked()
{
    //定义路径
    Path=QFileDialog ::getOpenFileName(this,
                                              "open","../","TXT(*.txt)");
     if(Path.isEmpty()==false)
     {
         //文件对象
         QFile file(Path);

         //打开文件，只读方式
         bool isok=file.open(QIODevice::ReadOnly);

         if(isok)
         {
             //读文件，默认识别utf8编码
             QByteArray array= file.readAll();

             //显示到编辑区
             ui->textEdit->setText(array);
         }
         //关闭文件
         file.close();
     }
}

//消除左递归算法
void xiaochu()
{
    cntdigui=cnt;
    for(int i=1;i<cnt;i++)
    {

        for(int j=1;j<i;j++)
        {
            Node *p=head[i].link; //遍历head[i]
            while(p)
            {
                std::string s=p->str;
                for(int k=0;k<int(s.size());k++)
                {
                    if(s[k]==head[j].id)
                    {
                        Node *firstnode=head[j].link;
                        std::string left=s.substr(0,k);
                        std::string right=s.substr(k+1,s.size()-k);
                        if(firstnode)
                        {
                            std::string ans;
                            ans+=left+firstnode->str+right;
                            p->str=ans;
                            firstnode=firstnode->next;
                        }


                        while(firstnode)
                        {
                            Node * newnode=new Node;
                            newnode->str=left+firstnode->str+right;
                            newnode->next=head[i].link;
                            head[i].link=newnode;
                            firstnode=firstnode->next;
                        }
                    }
                }
                p=p->next;
            }
        }


        //判断是否存在左递归
        bool flagdigui=false;
        Node *p =head[i].link;
        while(p)
        {
            char s=p->str[0];
            if(s==head[i].id)
            {
                flagdigui=true;
                break;
            }
            p=p->next;
        }

        Node *y=head[i].link;
        if(flagdigui)
        {
            head[cntdigui].id=endstr;
            mp[head[cntdigui].id]=cntdigui;
            while(y)
            {
                char s=y->str[0];
                if(s!=head[i].id)
                {
                    y->str+=endstr;
                }
                else {
                    Node *x=new Node;
                    x->str=y->str.substr(1,y->str.size()-1);
                    x->str=x->str+endstr;
                    x->next=head[cntdigui].link;
                    head[cntdigui].link=x;


                Node *p1=head[i].link;
                Node *temp=y;
                //cout<<head[i].id<<"-->"<<p->str<<endl;
                if(p1==temp)
                {
                    head[i].link=p1->next;

                }
                else {
                    while(p1->next!=temp) p1=p1->next;
                    p1->next=temp->next;
                }

                    //cout<<x->str<<" "<<"***"<<endl;
                }

                y=y->next;
            }

            Node * e=new Node;
            //Node *m=head[cntdigui].link;
            e->str="@";
            e->next=head[cntdigui].link;
            head[cntdigui].link=e;
            cntdigui++;
            endstr-=1;
        }
    }
}
void MainWindow::on_pushButton_5_clicked()
{
    xiaochu();
    puts("消除左递归后为");
    std::string tempstr;
    //遍历输出邻接表
    for(int i=1;i<cntdigui;i++)
    {

        tempstr.push_back(head[i].id);
        std::cout<<head[i].id;
        Node * p=head[i].link;
        while(p)
        {
            tempstr+="->"+p->str;
            std::cout<<"->"<<p->str;
            p=p->next;
        }
        std::cout<<std::endl;
        tempstr+="\n";
    }

    puts("化简文法");
    std::string tempstr1;
    huajianwenfa(cntdigui);
    for(int i=1;i<cntdigui;i++)
    {
        Node * p=head[i].link;
        while(p)
        {
            tempstr1.push_back(head[i].id);
            tempstr1+="->"+p->str+"\n";
            std::cout<<head[i].id;
            std::cout<<"->"<<p->str<<std::endl;
            p=p->next;
        }
    }
    QString qstr1=QString::fromStdString(tempstr1);
    ui->textEdit_3->setText(qstr1);
    std::cout<<"----------------------"<<std::endl;
}

//提取左公因子算法
void tiqu(int &cntdigui)
{
    for(int i=1;i<=cntdigui;i++)
    {
        Node *p=head[i].link;
        std::unordered_map<char,int> cntleft;
        std::unordered_map<char,std::set<Node*>> leftcnt;
        while(p)
        {
            cntleft[p->str[0]]++;
            p=p->next;
        }
        p=head[i].link;
        while(p)
        {
            if(cntleft[p->str[0]]>1)
            {
                //cout<<p->str[0]<<"******"<<endl;
                leftcnt[p->str[0]].insert(p);
            }
            p=p->next;
        }

        for(auto l:leftcnt)
        {
            head[cntdigui].id=endstr;
            mp[head[cntdigui].id]=cntdigui;

            for(auto s:l.second)
            {
                std::string strtemp=s->str;
                Node * e=new Node;
                e->str=strtemp.substr(1,strtemp.size()-1);
                e->next=head[cntdigui].link;
                head[cntdigui].link=e;
            }
            for(auto s:l.second)
            {
                std::string tempstr=s->str.substr(0,1)+endstr;
                s->str=tempstr;
            }
            cntdigui++;
            endstr-=1;
        }
    }
}

void MainWindow::on_pushButton_4_clicked()
{
    puts("提取左公因子后为:");
    tiqu(cntdigui);
    std::string tempstr1;
    for(int i=1;i<=cntdigui;i++)
    {

        std::cout<<head[i].id;
        Node * p=head[i].link;
        if(p)
        tempstr1.push_back(head[i].id);
        while(p)
        {
            tempstr1+="->"+p->str;
            std::cout<<"->"<<p->str;
            p=p->next;
        }
        tempstr1+="\n";
        std::cout<<std::endl;
    }
    QString qstr1=QString::fromStdString(tempstr1);
    ui->textEdit_4->setText(qstr1);
    std::cout<<"----------------------"<<std::endl;

}

//求first集算法
std::unordered_map<char,std::set<char>> first;
void First(int x)
{
    Node *p=head[x].link;
    while(p)
    {
        int cnt_=0;
        for(int i=0;i<int(p->str.size());i++)
        {
            std::unordered_map<char,std::set<char>> tempfirst;

            //如果终结符号或者@ 则first(xk)=xk
            if( (p->str[i]>='a' &&p->str[i]<='z') || p->str[i]=='@') first[p->str[i]].insert(p->str[i]);

            tempfirst[p->str[i]]=first[p->str[i]];
            tempfirst[p->str[i]].erase('@');
            for(auto xk:tempfirst[p->str[i]])
            {
                first[head[x].id].insert(xk);
            }

            if(!first[p->str[i]].count('@')) break;
            cnt_++;
        }
        if(cnt_==int(p->str.size())) first[head[x].id].insert('@');
        p=p->next;
    }
}
void MainWindow::on_pushButton_7_clicked()
{
    ui->tableWidget->setColumnCount(2);
    ui->tableWidget->setRowCount(cntdigui-1);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() << "非终结符" << "first集");
    ui->tableWidget->verticalHeader()->setVisible(false); // 隐藏水平header


    //从后往前遍历字符，求得first集
    for(int i=cntdigui;i>=1;i--)
    {
        First(i);
    }
    for(int i=1;i<cntdigui;i++)
    {
        First(i);
    }
    puts("所求的first集为:");
    for(int i=1;i<cntdigui;i++)
    {
        if(head[i].link)
        ui->tableWidget->setItem(i-1,0,new QTableWidgetItem(QString(head[i].id)));

        std::cout<<head[i].id<<"的first集\t";
        QString x;
        for(auto f:first[head[i].id])
        {
            x.push_back(f);
            x+=",";
            std::cout<<f<<" ";
        }
        if(!x.isEmpty())
        ui->tableWidget->setItem(i-1,1,new QTableWidgetItem(x));
        std::cout<<std::endl;
    }
    std::cout<<"----------------------"<<std::endl;
}

//求follow集
std::unordered_map<char,std::set<char>> follow;
void Follow(int x)
{
    follow['S'].insert('$');
    Node *p=head[x].link;
    while(p)
    {
        for(int i=0;i<int(p->str.size());i++)
        {
            if(p->str[i]>='A' && p->str[i]<='Z')
            {
                if(i==int(p->str.size()-1))
                {
                    for(auto f:follow[head[x].id])
                    {
                        follow[p->str[i]].insert(f);
                    }
                }
                for(int k=i+1;k<int(p->str.size());k++)
                {
                    if(p->str[k]<='z' && p->str[k]>='a')
                    {
                        follow[p->str[i]].insert(p->str[k]);
                        break;
                    }
                    else {
                        std::unordered_map<char,std::set<char>> tempfirst;
                        tempfirst[p->str[k]]=first[p->str[k]];
                        tempfirst[p->str[k]].erase('@');
                        for(auto f:tempfirst[p->str[k]])
                        {
                            follow[p->str[i]].insert(f);
                        }
                        if(!first[p->str[k]].count('@')) break;
                    }
                    bool flagfirst=true;
                    for(int j=i+1;j<int(p->str.size());j++)
                    {
                        if(!first[p->str[j]].count('@'))
                        {
                            flagfirst=false;
                            break;
                        }
                    }
                    if(flagfirst)
                    {
                        for(auto f:follow[head[x].id])
                        {
                            follow[p->str[i]].insert(f);
                        }
                    }

                }
            }


        }
        p=p->next;
    }

}
void MainWindow::on_pushButton_6_clicked()
{
    ui->tableWidget_2->setColumnCount(2);
    ui->tableWidget_2->setRowCount(cntdigui-1);
    ui->tableWidget_2->setHorizontalHeaderLabels(QStringList() << "非终结符" << "follow集");
    ui->tableWidget_2->verticalHeader()->setVisible(false); // 隐藏水平header
    for(int i=cntdigui;i>=1;i--)
    {
        Follow(i);
    }
    for(int i=1;i<=cntdigui;i++)
    {
        Follow(i);
    }
    puts("所求的Follow集为:");
    for(int i=1;i<cntdigui;i++)
    {
        if(head[i].link)
        ui->tableWidget_2->setItem(i-1,0,new QTableWidgetItem(QString(head[i].id)));
        std::cout<<head[i].id<<"的follow集\t";
        QString x;
        for(auto f:follow[head[i].id])
        {
            x.push_back(f);
            x+=',';
            std::cout<<f<<" ";
        }

        if(!x.isEmpty())
        ui->tableWidget_2->setItem(i-1,1,new QTableWidgetItem(x));
        std::cout<<std::endl;
    }
    std::cout<<"----------------------"<<std::endl;
}

//最左推导算法
void MainWindow:: zuizuotuidao(std::string &chuan)
{
    ui->tableWidget_3->setColumnCount(3);
    ui->tableWidget_3->setRowCount(20);
    ui->tableWidget_3->setHorizontalHeaderLabels(QStringList() << "符号栈" << "输入串"<<"动作");
    char stk[N];
    int top=0;
    stk[++top]='$';
    stk[++top]=head[1].id;
    int t=chuan.size();

    int row=0;

    for(int i=0;i<t;)
    {
        QString tempstk;
        for(int k=1;k<=top;k++)
        {
            tempstk.push_back(stk[k]);
            std::cout<<stk[k];
        }
        ui->tableWidget_3->setItem(row,0,new QTableWidgetItem(tempstk));

        std::cout<<"\t"<<chuan.substr(i,chuan.size()-i)<<"\t";
        ui->tableWidget_3->setItem(row,1,new QTableWidgetItem(QString::fromStdString(chuan.substr(i,chuan.size()-i))));

        if(stk[top]==chuan[i]&&stk[top]=='$')
        {
            top--;
            i++;
            puts("匹配");
            ui->tableWidget_3->setItem(row,2,new QTableWidgetItem("成功"));
            row++;
            continue;
        }
        if(stk[top]==chuan[i])
        {
            top--;
            i++;
            puts("匹配");
            ui->tableWidget_3->setItem(row,2,new QTableWidgetItem("匹配"));
            row++;
            continue;
        }


        Node *p=head[mp[stk[top]]].link;
        bool flag=false;

        while(p)
        {
            QString tempstk2;
            if(first[p->str[0]].count(chuan[i]))
            {
                tempstk2.push_back(stk[top]);
                tempstk2+="->";
                tempstk2+=QString::fromStdString(p->str);

                std::cout<<stk[top]<<"->";
                std::cout<<p->str<<std::endl;
                ui->tableWidget_3->setItem(row,2,new QTableWidgetItem(tempstk2));

                flag=true;
                top--;
                for(int j=p->str.size()-1;j>=0;j--)
                stk[++top]=p->str[j];
                row++;
                break;
            }
            p=p->next;
        }
        QString tempstk3;
        if(first[stk[top]].count('@'))
        {
            if(follow[head[mp[stk[top]]].id].count(chuan[i]))
            {
                tempstk3.push_back(stk[top]);
                tempstk3+="->";
                tempstk3.push_back('@');
                std::cout<<stk[top]<<"->";
                std::cout<<"@"<<std::endl;
                ui->tableWidget_3->setItem(row,2,new QTableWidgetItem(tempstk3));
                top--;
                flag=true;
                row++;
                continue;
            }
        }
        if(!flag)
        {
            puts("匹配失败");
            return ;
        }
    }
    puts("成功");
}
void MainWindow::on_pushButton_8_clicked()
{
    QString x=ui->lineEdit->text();
    std::string s =x.toStdString();
    zuizuotuidao(s);
}
