#include<bits/stdc++.h>
using namespace std;

const int N=110;
string str;
unordered_map<char,int> mp;//���ս��������Ƿ���� 
unordered_map<char,bool> mpr; //�жϷ��ս���Ƿ����ұ߳��� 

int cnt=1;
int cntidx=1;
struct Node{
	string str;
	Node * next;
}; 
struct Head{
	char id;
	Node * link;
}head[N];
set<string> ans;
string path[N];
vector<string> temp;
ofstream os2("huajianwenfa.txt");

string chuan; 
void init()
{
	//��ʼ���ṹ�� 
//	memset(wenfa,0,sizeof (struct Rule)*N);
	memset(head,0,sizeof (struct Head)*N);
	ofstream os("wenfa.txt");
	ifstream is("wenfa.txt");
	
	while(cin>>str)
 	{
 		os<<str<<endl;
 		//�к����� 
 		if(str[0]==str[3] &&str.size()==4)
 		{
 			continue;
		}
		//���������Ч�ַ����浽�ַ������� 
 		temp.push_back(str[0]+str.substr(3,str.size()-3));
 		
		//�жϲ�����ʼ���ŵķ��ս���Ƿ����ұ߳��� 
		for(int i=3;i<str.size();i++)
		{
			if(str[i]>='A'&&str[i]<='Z')
			mpr[str[i]]=true;
		}
	}
	
	
	for(int i=0;i<temp.size();i++)
	{
		//�����ұ�û�г��ֵĵ��ǲ�����ʼ���ŵķ��ս����������Ч�ķ� 
		if(!mpr[temp[i][0]]&&temp[i][0]!='S') continue;
		
		//�½�һ�����ս��ͷ��� 
		if(!mp[temp[i][0]]) 
		{
			mp[temp[i][0]]=cnt;
			head[mp[temp[i][0]]].link=NULL;
			cnt++;
		}
		
		//�ڽӱ���ͼ 
		head[mp[temp[i][0]]].id=temp[i][0];
 		Node *p =new Node;
 		p->str=temp[i].substr(1,temp[i].size()-1);
 		p->next=head[mp[temp[i][0]]].link;
 		head[mp[temp[i][0]]].link=p;
	}
	
	puts("��������ڽӱ�");
	//��������ڽӱ� 
	for(int i=1;i<cnt;i++)
	{
		cout<<head[i].id;
		Node * p=head[i].link;
		while(p)
		{
			cout<<"->"<<p->str;
			p=p->next;
		}
		cout<<endl;
	}
	//cout<<"cnt"<<cnt<<endl;
}

//�����ҳ����е���Ч�ķ� 
unordered_map<Node *,bool> visited;
void dfs(int i,Node *v, bool& flag)
{
	//cout << v->str << endl;
	if (flag) {
		return;
	}
	visited[v]=true;
	if((v->str[0]>='a' && v->str[0]<='z') || v->str[0]=='@')
	{
		flag = true;
		return;
	}
	for(int i=0;i<v->str.size();i++)
	{
		if(v->str[i]>='A' && v->str[i]<='Z')
		{
			int idx=mp[v->str[i]];
			Node *w=head[idx].link;
			while(w)
			{
				if(!visited[w])
				{	
					dfs(idx,w,flag);
				}
				w=w->next;	
			}

		}
	}
}
void huajianwenfa(int cnt)
{
	for(int i=1;i<cnt;i++)
	{
		Node * p=head[i].link;
		while(p)
		{
			bool flag = false;
			visited.clear();
			dfs(i,p, flag);
			if(flag)
			{
				//cout<<"idx"<<mp[head[i].id]<<":"<<head[i].id<<endl;
			}
			else {
				Node *p1=head[i].link;
				//cout<<head[i].id<<"-->"<<p->str<<endl;
				if(p1==p)
				{
					head[i].link=p1->next;
					
				}
				else {
					while(p1->next!=p) p1=p1->next;
					p1->next=p->next;
				}
			}
			p=p->next;
		}
	}
}
int cntdigui;
char endstr='Z'; //�µķ��ս�� 
void xiaochu()
{
	cntdigui=cnt;
	for(int i=1;i<cnt;i++)
	{
		
		for(int j=1;j<i;j++)
		{
			Node *p=head[i].link; //����head[i] 
			while(p)
			{
				string s=p->str;
				for(int k=0;k<s.size();k++)
				{
					if(s[k]==head[j].id)
					{
						Node *firstnode=head[j].link;							
						string left=s.substr(0,k);
						string right=s.substr(k+1,s.size()-k);
						if(firstnode)
						{
							string ans;
							ans+=left+firstnode->str+right;
							p->str=ans;
							firstnode=firstnode->next;
						}

						
						while(firstnode)
						{
							Node * newnode=new Node;
							newnode->str=left+firstnode->str+right;
							newnode->next=head[i].link;
							head[i].link=newnode; 
							firstnode=firstnode->next;
						}
					}
				}
				p=p->next;
			}
		}
//		
		bool flagdigui=false;
		Node *p =head[i].link;
		while(p)
		{
			char s=p->str[0];
			if(s==head[i].id)
			{
				flagdigui=true;
				break;
			}
			p=p->next;
		}
		
		Node *y=head[i].link;
		if(flagdigui)
		{
			head[cntdigui].id=endstr;
			mp[head[cntdigui].id]=cntdigui;
			while(y)
			{
				char s=y->str[0];
				if(s!=head[i].id)
				{
					y->str+=endstr;
				}
				else {
					Node *x=new Node;
					x->str=y->str.substr(1,y->str.size()-1);
					x->str=x->str+endstr;
 					x->next=head[cntdigui].link;
 					head[cntdigui].link=x;
 					
 					
 				Node *p1=head[i].link;
 				Node *temp=y;
				//cout<<head[i].id<<"-->"<<p->str<<endl;
				if(p1==temp)
				{
					head[i].link=p1->next;
					
				}
				else {
					while(p1->next!=temp) p1=p1->next;
					p1->next=temp->next;
				}
 					
 					//cout<<x->str<<" "<<"***"<<endl;
				}
				
				y=y->next;
			}
			
			Node * e=new Node;
			//Node *m=head[cntdigui].link;
			e->str="@";
			e->next=head[cntdigui].link;
 			head[cntdigui].link=e;
 			cntdigui++;
 			endstr-=1;
		}
	}
}

void tiqu(int &cntdigui)
{
	for(int i=1;i<=cntdigui;i++)
	{
		Node *p=head[i].link;
		unordered_map<char,int> cntleft;
		unordered_map<char,set<Node*>> leftcnt;
		while(p)
		{
			cntleft[p->str[0]]++;
			p=p->next;
		}
		p=head[i].link;
		while(p)
		{
			if(cntleft[p->str[0]]>1)
			{
				//cout<<p->str[0]<<"******"<<endl;
				leftcnt[p->str[0]].insert(p);
			}
			p=p->next;
		}
		
		for(auto l:leftcnt)
		{
			head[cntdigui].id=endstr;
			mp[head[cntdigui].id]=cntdigui;
			
			for(auto s:l.second)
			{
				string strtemp=s->str;
				Node * e=new Node;
				e->str=strtemp.substr(1,strtemp.size()-1);
				cout<<e->str<<"******"<<endl;
				e->next=head[cntdigui].link;
 				head[cntdigui].link=e;
			}
			for(auto s:l.second)
			{
				string tempstr=s->str.substr(0,1)+endstr;
 				s->str=tempstr;
			}
			cntdigui++;
			endstr-=1;
		}	
	} 
}
 
//��first���㷨 
unordered_map<char,set<char>> first;
void First(int x)
{
	Node *p=head[x].link;
	while(p)
	{
		int cnt_=0;
		for(int i=0;i<p->str.size();i++)
		{
			unordered_map<char,set<char>> tempfirst;
			
			//����ս���Ż���@ ��first(xk)=xk 
			if(p->str[i]>='a' &&p->str[i]<='z' || p->str[i]=='@') first[p->str[i]].insert(p->str[i]);
			
			tempfirst[p->str[i]]=first[p->str[i]];
			tempfirst[p->str[i]].erase('@');
			for(auto xk:tempfirst[p->str[i]])
			{
				first[head[x].id].insert(xk);
			}
			
			if(!first[p->str[i]].count('@')) break;
			cnt_++;
		}
		if(cnt_==p->str.size()) first[head[x].id].insert('@');
		p=p->next; 
	}	
}

//��follow�� 
unordered_map<char,set<char>> follow;
void Follow(int x)
{
	follow['S'].insert('$');
	Node *p=head[x].link;
	while(p)
	{
		for(int i=0;i<p->str.size();i++)
		{
			if(p->str[i]>='A' && p->str[i]<='Z')
			{
				if(i==p->str.size()-1)
				{
					for(auto f:follow[head[x].id])
					{
						follow[p->str[i]].insert(f);
					}
				}
				for(int k=i+1;k<p->str.size();k++)
				{
					if(p->str[k]<='z' && p->str[k]>='a')
					{
						follow[p->str[i]].insert(p->str[k]);
						break;
					}
					else {
						unordered_map<char,set<char>> tempfirst;
						tempfirst[p->str[k]]=first[p->str[k]];
						tempfirst[p->str[k]].erase('@');
						for(auto f:tempfirst[p->str[k]])
						{
							follow[p->str[i]].insert(f);
						}
						if(!first[p->str[k]].count('@')) break;
					}
					bool flagfirst=true;
					for(int j=i+1;j<p->str.size();j++)
					{
						if(!first[p->str[j]].count('@')) 
						{
							flagfirst=false;
							break;
						}
					}
					if(flagfirst)
					{
						for(auto f:follow[head[x].id])
						{
							follow[p->str[i]].insert(f);
						}
					}
					
				}
			}
			
			
		}
		p=p->next;
	}
	
}
void zuizuotuidao()
{
	string chuan="abd$";
	char stk[N];
	int top=0;
	stk[++top]='$';
	stk[++top]=head[1].id;
	int t=chuan.size();
	for(int i=0;i<t;)
	{
		
		for(int k=1;k<=top;k++) cout<<stk[k];
		cout<<"\t"<<chuan.substr(i,chuan.size()-i)<<"\t";
		
		if(stk[top]==chuan[i])
		{
			top--;
			i++;
			puts("ƥ��");
			continue;
		}
		
		Node *p=head[mp[stk[top]]].link;
		bool flag=false;
		while(p)
		{
			if(first[p->str[0]].count(chuan[i]))
			{
				cout<<stk[top]<<"->";
				cout<<p->str<<endl;
				flag=true;
				top--;
				for(int j=p->str.size()-1;j>=0;j--)
				stk[++top]=p->str[j];
				break;
			}
			p=p->next;
		}
		if(first[stk[top]].count('@'))
		{
		if(follow[head[mp[stk[top]]].id].count(chuan[i]))
		{
			cout<<stk[top]<<"->";
			cout<<"@"<<endl;
			top--;
			flag=true;
			continue;
		}
		}
		if(!flag)
		{
			puts("ƥ��ʧ��");
			return ;
		}
	}
	puts("�ɹ�"); 
}
int main()
{

	init();

	huajianwenfa(cnt);
	puts("�������ķ�Ϊ:"); 
	for(int i=1;i<cnt;i++)
	{
//		if(head[i].link)
//		cout<<head[i].id;
		Node * p=head[i].link;
		while(p)
		{
			//int cnt=0;
			cout<<head[i].id;
			cout<<"->"<<p->str<<endl;
			os2<<head[i].id;
			os2<<"->"<<p->str<<endl;
			p=p->next;
			//cnt++;
		}
	}
	puts("��������ڽӱ�");
	//��������ڽӱ� 
	for(int i=1;i<cnt;i++)
	{
		if(head[i].link)
		cout<<head[i].id;
		Node * p=head[i].link;
		while(p)
		{
			cout<<"->"<<p->str;
			p=p->next;
		}
		cout<<endl;
	}
	
	xiaochu();
	puts("������ݹ��Ϊ");
	//��������ڽӱ� 
	for(int i=1;i<cntdigui;i++)
	{
		if(head[i].link)
		cout<<head[i].id;
		Node * p=head[i].link;
		while(p)
		{
			cout<<"->"<<p->str;
			p=p->next;
		}
		cout<<endl;
	}
//	cout<<"cntdigui�ĸ���Ϊ"<<cntdigui<<endl;
//	cout<<"ends"<<endstr<<endl;
	cout<<"----------------------"<<endl;
	puts("�����ķ�");
	huajianwenfa(cntdigui);
	for(int i=1;i<cntdigui;i++)
	{
//		if(head[i].link)
//		cout<<head[i].id;
		Node * p=head[i].link;
		while(p)
		{
			//int cnt=0;
			cout<<head[i].id;
			cout<<"->"<<p->str<<endl;
			os2<<head[i].id;
			os2<<"->"<<p->str<<endl;
			p=p->next;
			//cnt++;
		}
	}
	cout<<"----------------------"<<endl;
	puts("��ȡ�����Ӻ�Ϊ:");
	tiqu(cntdigui);
	for(int i=1;i<=cntdigui;i++)
	{
		if(head[i].link)
		cout<<head[i].id;
		Node * p=head[i].link;
		while(p)
		{
			cout<<"->"<<p->str;
			p=p->next;
		}
		cout<<endl;
	}
	cout<<"----------------------"<<endl;

	//�Ӻ���ǰ�����ַ������first�� 
	for(int i=cntdigui;i>=1;i--)
	{
		First(i);
	}
	for(int i=1;i<cntdigui;i++)
	{
		First(i);
	}
	puts("�����first��Ϊ:");
	for(int i=1;i<cntdigui;i++)
	{
		if(head[i].link)
		cout<<head[i].id<<"��first��\t";
		for(auto f:first[head[i].id])
		{
			cout<<f<<" ";
		}
		cout<<endl;
	}
	cout<<"----------------------"<<endl;
	for(int i=cntdigui;i>=1;i--)
	{
		Follow(i);
	}
	for(int i=1;i<=cntdigui;i++)
	{
		Follow(i);
	}
	puts("�����Follow��Ϊ:");
	for(int i=1;i<cntdigui;i++)
	{
		if(head[i].link)
		cout<<head[i].id<<"��follow��\t";
		for(auto f:follow[head[i].id])
		{
			cout<<f<<" ";
		}
		cout<<endl;
	}
	cout<<"----------------------"<<endl;
	zuizuotuidao();
	return 0;
}
/*
S->Be
B->Ce
B->Af
A->Ae
A->e
C->Cf
D->f
*/



/*
S->Sa
S->Abc
S->dA
A->Sef
A->gAh
A->x
*/

/*
S->d
S->aaB
S->aaaC
S->aaaDd
S->f
S->Sm
B->x
C->y
D->Z
*/


/*
S->A
A->a
S->d
S->f
S->aabe
S->aabb
S->aabf
S->abc
S->abf
S->ad
S->bf
S->bc 
*/

/*
S->Sa
S->b
*/

/*
S->ABC
S->D
A->aB
A->@
B->cC
B->@
C->eC
C->@
D->i
D->j
*/

/*
S->AB
S->bC
A->b
A->@
B->aD
B->@
C->AD
C->b
D->aS
D->c
*/

/*
S->ABc
A->a
A->@
B->b
B->@ 
*/

/*
S->ABC
A->aB
A->bB
B->cC
B->@
C->ef
C->gh
*/


/*
S->Ab
S->Bc
A->aA
A->dB
B->c
B->e 
*/
 
/*
S->AB
S->bC
A->b
A->@
B->aD
B->@
C->AD
C->b
D->c
D->aS
*/

/*
S->d
S->aaB
S->aaaC
S->aaaDd
S->f
*/
 

