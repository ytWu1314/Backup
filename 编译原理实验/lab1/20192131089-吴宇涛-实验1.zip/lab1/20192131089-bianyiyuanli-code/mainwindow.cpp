/*头文件*/
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPainter>
#include <QGraphicsOpacityEffect>
#include <QFile>
#include <QFileDialog>
#include<QString>
#include<iostream>
#include<cstring>
#include<fstream>
#include<vector>
#include<unordered_map>
#include<QTextCodec>
#include<QLabel>
#include <QTextStream>
QTextStream cout(stdout,  QIODevice::WriteOnly);

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);

    this->setObjectName("mainWindow");
    this->setStyleSheet("#mainWindow{border-image:url(:/bianyiyuanli.png);}");
}

MainWindow::~MainWindow()
{
    delete ui;
}

std::string path3="./output.txt";

QString inputpath;
std::string str;
std::unordered_map<char,bool> hash_del;
std::unordered_map<std::string,bool> hash_key;
std::vector<std::string> keyword={"break","case","char","continue","do","default","double","else","float","for","if","int","include","long","main","return","switch","typedef","void","unsigned","while","iostream","cin","cout"};
std::string temp_zhushi;
bool Flag;
//判断数字，浮点型数字，科学计数法
bool fnum(char s)
{
    return isdigit(s)|| s=='.'||s=='e'||s=='-'||s=='+'||s=='E';
}
//初始化关键字哈希表
void init()
{
    for(unsigned int i=0;i<keyword.size();i++)
    hash_key[keyword[i]]=true;
}
//C++单词拼装
void MainWindow::init2()
{
    std::ifstream in(inputpath.toStdString());
    std::ofstream out(path3);
    init();
    while(!in.eof())
    {
        //逐行扫描文件，存到字符串str
        getline(in,str);
        for(int i=0;i<int(str.size());i++)
        {
            int j=i;
            std::string temp_num="";
            std::string temp_id="";
            std::string temp_key="";
            std::string temp_chars="";
            std::string temp_string="";
            std::string temp_op="";

            //数字或者"+","-"开头: 数字常量，浮点数，科学计数法，负数
            if(isdigit(str[j])||(isdigit(str[j+1])&&(str[j]=='-'||str[j]=='+')))
            {
                while(fnum(str[j])&&j<(int)str.size())
                {
                    temp_num+=str[j];
                    j++;
                }
                out<<"数字\t"<<temp_num<<std::endl;
                j--;
                i=j;
                continue;
            }

            //字母开头:标识符/关键字
            if(isalpha(str[j])||str[j]=='_')
            {
                while((isalpha(str[j])||str[j]=='_'||isdigit(str[j]))&&(j<int(str.size())))
                {
                    temp_id+=str[j];
                    j++;
                }
                j--;
                if(!hash_key[temp_id])
                out<<"标识符\t"<<temp_id<<std::endl;
                else out<<"关键字\t"<<temp_id<<std::endl;

            }

            //特殊符号
            if(!isdigit(str[j])&&!isalpha(str[j]))
            {
                if(str[j]=='#'||str[j]==','||str[j]==';'||str[j]=='{'||str[j]=='}'||str[j]=='~'||str[j]=='('||str[j]==')')
                {
                    out<<"特殊符号\t"<<str[j]<<std::endl;
                    continue;
                }

                //字符常量
                else if(str[j]=='\'')
                {
                    for(int x=0;x<3;x++)
                    {
                        temp_chars+=str[j];
                        j++;
                    }
                    out<<"字符\t"<<temp_chars<<std::endl;
                }
                //字符串常量
                else if(str[j]=='\"')
                {
                    temp_string+=str[j],j++;
                    while(str[j]!='\"'&&j<int(str.size()))
                    {
                        temp_string+=str[j];
                        j++;
                    }
                    temp_string+=str[j];
                    out<<"字符串\t"<<temp_string<<std::endl;
                }
                //<iostream.h> 特殊符号
                else if(str[j]=='<'&&isalpha(str[j+1]))
                {
                    temp_op+=str[j],j++;
                    while(str[j]!='>'&&j<int(str.size()))
                    {
                        temp_op+=str[j];
                        j++;
                    }
                    temp_op+=str[j];
                    out<<"特殊符号\t"<<temp_op<<std::endl;
                }
                // < << <<= 运算符
                else if(str[j]=='<')
                {
                    temp_op+=str[j],j++;
                    if(str[j]=='<'||str[j]=='=')
                    {
                        temp_op+=str[j],j++;
                        if(str[j]=='=')
                        {
                            temp_op+=str[j];
                        }
                    }
                    out<<"特殊符号\t"<<temp_op<<std::endl;
                    j--;
                }
                //> >> >>= 运算符
                else if(str[j]=='>')
                {
                    temp_op+=str[j],j++;
                    if(str[j]=='>'||str[j]=='=')
                    {
                        temp_op+=str[j],j++;
                        if(str[j]=='=')
                        {
                            temp_op+=str[j];
                        }
                    }
                    out<<"特殊符号\t"<<temp_op<<std::endl;
                    j--;
                }
                //= == 运算符
                else if(str[j]=='=')
                {
                    if(str[j+1]!='=')
                    {
                        out<<"特殊符号\t"<<str[j]<<std::endl;
                    }
                    else {
                        out<<"特殊符号\t"<<str[j]<<str[j+1]<<std::endl;
                        j++;
                    }
                }
                //+ ++ += 运算符
                else if(str[j]=='+'){
                    if(str[j+1]=='+'||str[j+1]=='=')
                    {
                        out<<"特殊符号\t"<<str[j]<<str[j+1]<<std::endl;
                    }
                    else out<<"特殊符号\t"<<str[j]<<std::endl;
                }
                //- -- -= 运算符
                else if(str[j]=='-'){
                    if(str[j+1]=='-'||str[j+1]=='=')
                    {
                        out<<"特殊符号\t"<<str[j]<<str[j+1]<<std::endl;
                    }
                    else out<<"特殊符号\t"<<str[j]<<std::endl;
                }
                //& && &=运算符
                else if(str[j]=='&'){
                    if(str[j+1]=='&'||str[j+1]=='=')
                    {
                        out<<"特殊符号\t"<<str[j]<<str[j+1]<<std::endl;
                    }
                    else out<<"特殊符号\t"<<str[j]<<std::endl;
                }
                //| || |= 运算符
                else if(str[j]=='|'){
                    if(str[j+1]=='|'||str[j+1]=='=')
                    {
                        out<<"特殊符号\t"<<str[j]<<str[j+1]<<std::endl;
                    }
                    else out<<"特殊符号\t"<<str[j]<<std::endl;
                }
                //* *= 运算符
                else if(str[j]=='*'){
                    if(str[j+1]=='=')
                    {
                        out<<"特殊符号\t"<<str[j]<<str[j+1]<<std::endl;
                        j++;
                    }
                    else out<<"特殊符号\t"<<str[j]<<std::endl;
                }
                // / /= 运算符  注释// /**/
                else if(str[j]=='/'){
                    if(str[j+1]=='=')
                    {
                        out<<"特殊符号\t"<<str[j]<<str[j+1]<<std::endl;
                        j++;
                    }
                    else if(str[j+1]!='/'&&str[j+1]!='*') out<<"特殊符号\t"<<str[j]<<std::endl;
                    if(str[j+1]=='/')
                    {
                        out<<"注释\t"<<str<<std::endl;
                        break;
                    }
                    else if(str[j+1]=='*')
                    {
                        temp_zhushi+=str[j];
                        temp_zhushi+=str[j+1];
                        Flag=true;
                        j+=2;
                        while(j<int(str.size())||Flag)
                        {
                            if(j==int(str.size()))
                            {
                                getline(in,str);
                                j=0;
                            }
                            if(str[j]=='*'&&str[j+1]=='/')
                            {
                                Flag=false;
                                break;
                            }
                            temp_zhushi+=str[j];
                            j++;
                        }
                        temp_zhushi+=str[j];
                        temp_zhushi+=str[j+1];
                        i=j+1;
                        out<<"注释\t"<<temp_zhushi<<std::endl;
                        temp_zhushi="";
                        continue;
                    }

                }
                // ! != 运算符
                else if(str[j]=='!'){
                    if(str[j+1]=='=')
                    {
                        out<<"特殊符号\t"<<str[j]<<str[j+1]<<std::endl;
                        j++;
                    }
                    else out<<"特殊符号\t"<<str[j]<<std::endl;
                }
                // ^ ^= 运算符
                else if(str[j]=='^'){
                    if(str[j+1]=='=')
                    {
                        out<<"特殊符号\t"<<str[j]<<str[j+1]<<std::endl;
                        j++;
                    }
                    else out<<"特殊符号\t"<<str[j]<<std::endl;
                }
                //% %= 运算符
                else if(str[j]=='%'){
                    if(str[j+1]=='=')
                    {
                        out<<"特殊符号\t"<<str[j]<<str[j+1]<<std::endl;
                        j++;
                    }
                    else out<<"特殊符号\t"<<str[j]<<std::endl;
                }
            }
            i=j;
          }
    }
}
//从文件中读取单词
void MainWindow::on_pushButton_clicked()
{
   //定义路径
   QString path;
   path=QFileDialog ::getOpenFileName(this,
                                             "open","../","TXT(*.txt)");
   cout<<path<<endl;
    if(path.isEmpty()==false)
    {
        //文件对象
        QFile file(path);

        //打开文件，只读方式
        bool isok=file.open(QIODevice::ReadOnly);

        if(isok)
        {
            //读文件，默认识别utf8编码
            QByteArray array= file.readAll();

            //显示到编辑区
            ui->textEdit->setText(array);
        }
        //关闭文件
        file.close();
    }
    inputpath= path;
    cout<<inputpath<<endl;
}

//读取输出文件显示到textbrowser
void MainWindow::on_pushButton_2_clicked()
{
     MainWindow::init2();
     //定义路径
     QString path2 =QString::fromStdString(path3);
     if(path2.isEmpty()==false)
     {
         //文件对象
         QFile file(path2);

         //打开文件，只读方式
         bool isok=file.open(QIODevice::ReadOnly);

         if(isok)
         {
             //读文件，默认识别utf8编码
             QByteArray array;
             array=file.readAll();

             //显示到编辑区
             ui->textBrowser->setText(array);
         }
         //关闭文件
         file.close();
     }
}
