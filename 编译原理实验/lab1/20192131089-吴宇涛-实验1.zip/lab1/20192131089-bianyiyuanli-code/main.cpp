#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setWindowTitle("C++_word_assembler");
    w.setWindowIcon(QIcon(":/scnu_byyl.ico"));
    w.show();
    w.show();
    return a.exec();
}
