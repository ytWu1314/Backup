* `20192131089-byyllab2xlex-code` 文件夹中的代码需要在没有中文路径下运行
* 本次使用的`IDE:VScode`  编码为`utf-8` 如果遇到乱码可以使用`notepad++` 改一下编码
* `xlex.cpp` 是`dos`版的实验2
* `dfatocode.cpp` 是简化版的实验2最后一步 
* `demo` 文件夹中的`exe` 文件可以直接运行
