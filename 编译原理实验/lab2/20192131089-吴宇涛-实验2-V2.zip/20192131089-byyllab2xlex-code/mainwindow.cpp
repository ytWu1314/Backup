#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPainter>
#include <QGraphicsOpacityEffect>
#include <QFile>
#include <QFileDialog>
#include<QString>
#include<iostream>
#include<cstring>
#include<fstream>
#include<vector>
#include<unordered_map>
#include<QTextCodec>
#include<QLabel>
#include <QTextStream>
#include<fstream>
#include<bits/stdc++.h>
#include <QTableWidget>
#include <QTableWidgetItem>
using namespace  std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setObjectName("mainWindow");
    this->setStyleSheet("#mainWindow{border-image:url(:/bianyiyuanli.png);}");
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool isdigitoralpha(char s)
{
    if (isdigit(s) || isalpha(s))
        return true;
    return false;
}
int priority(char s)
{
    switch (s)
    {
    case '*':
        return 4;
    case '.':
        return 3;
    case '|':
        return 2;
    default:
        return 1;
    }
}
std::string post(std::string &x) {
    std::string output;
    std::stack<char> s;
    for(int i=0; i<int(x.size()); i++) {
        if(isdigitoralpha(x[i])) {
            output+=x[i];
        } else
            switch(x[i]) {
                case '(':
                    s.push(x[i]);
                    break;
                case ')':
                    while(s.top()!='(') {
                        output+=s.top();
                        s.pop();
                    }
                    s.pop();
                    break;
                default :
                    while(!s.empty()) {
                        char a=s.top();
                        if(priority(a)>=priority(x[i])) {
                            output+=s.top();
                            s.pop();
                        } else break;
                    }
                    s.push(x[i]);
            }
    }
    while(!s.empty()) {
        output+=s.top();
        s.pop();
    }
    return output;
}

//NFA有关的全局变量
const int N = 261;
int idx = 0;
struct NFA
{
    int from;
    int to;
    char edge;
} nfa[N];
char nfas[N][N]; //nfa 有一对多的情况 所以只能使用 点-点 的邻接矩阵

int cnt = 1;
int startstate =0;

//出现的字符
bool ialpha[1000];
int cntop;
vector<char> ch;

void retoNFA(string &s)
{
    //后缀正则表达式转NFA
    stack<NFA> st;
    for (int i = 0; i < (int)s.size(); i++)
    {
        if (isdigitoralpha(s[i]))
        {
            if (ialpha[s[i] - '0'] == false)
            {
                ialpha[s[i] - '0'] = true;
                ch.push_back(s[i]);
                cntop++;
            }
            if(startstate==0) startstate=cnt;
            nfa[idx].from = cnt++;
            nfa[idx].to = cnt++;
            nfa[idx].edge = s[i];
            nfas[nfa[idx].from][nfa[idx].to] = s[i];
            st.push(nfa[idx++]);
        }
        if (s[i] == '|')
        {
            nfa[idx].from = cnt++;
            nfa[idx].to = cnt++;

            NFA s1 = st.top();
            st.pop();
            NFA s2 = st.top();
            st.pop();

            nfas[nfa[idx].from][s1.from] = 'e';
            nfas[nfa[idx].from][s2.from] = 'e';

            nfas[s1.to][nfa[idx].to] = 'e';
            nfas[s2.to][nfa[idx].to] = 'e';

            st.push(nfa[idx++]);
        }
        if (s[i] == '*')
        {
            nfa[idx].from = cnt++;
            nfa[idx].to = cnt++;

            NFA s1 = st.top();
            st.pop();

            nfas[nfa[idx].from][s1.from] = 'e';
            nfas[s1.to][nfa[idx].to] = 'e';
            nfas[s1.to][s1.from] = 'e';
            nfas[nfa[idx].from][nfa[idx].to] = 'e';

            st.push(nfa[idx++]);
        }
        if (s[i] == '.')
        {
            NFA s1 = st.top();
            st.pop();

            NFA s2 = st.top();
            st.pop();

            nfa[idx].from = s2.from;
            nfa[idx].to = s1.to;

            nfas[s2.to][s1.from] = 'e';

            st.push(nfa[idx++]);
        }
    }

    //输出NFA图
    for (int i = 1; i <= cnt - 1; i++)
    {
        for (int j = 1; j <= cnt - 1; j++)
        {
            if (isalpha(nfas[i][j]))
                cout << i << "->" << j << ":" << nfas[i][j] << " ";
            // else cout<<i<<"->"<<j<<":none"<<" ";
        }
        cout << endl;
    }
}

set<int> delta(set<int> x, char c)
{
    set<int> temp;
    for (auto X : x)
    {
        for (int j = 1; j <= cnt - 1; j++)
        {
            if (nfas[X][j] == c)
                temp.insert(j);
        }
    }
    return temp;
}

bool visit[N];
set<int> eclosure(set<int> x)
{
    memset(visit, false, sizeof visit);
    set<int> closure;

    queue<int> q;

    for (auto X : x)
        q.push(X);

    while (q.size())
    {
        int t = q.front();
        q.pop();
        closure.insert(t);
        for (int j = 1; j <= cnt - 1; j++)
        {
            if (nfas[t][j] == 'e')
            {
                if (!visit[j])
                {
                    q.push(j);
                    visit[j] = true;
                }
            }
        }
    }
    return closure;
}
set<set<int>> Q;
void nfatodfa()
{

    int nfastart = nfa[idx - 1].from;

    set<int> q = eclosure({nfastart});
    Q.insert(q);

    queue<set<int>> worklist;
    worklist.push(q);

    while (worklist.size())
    {

        auto t = worklist.front();
        worklist.pop();

        for (int i = 0; i < cntop; i++)
        {
            set<int> T = eclosure(delta(t, ch[i]));

            if (!Q.count(T) && T.size())
            {
                Q.insert(T);
                worklist.push(T);
            }
        }
    }
}

set<int> display(set<int> aset, char c)
{
    return eclosure(delta(aset, c));
}

set<int> NA;
set<int> AC;
int gdfa[N][N];
map<set<int>, int> hashdfa;
void printdfa()
{
    memset(gdfa, -1, sizeof gdfa);
    int nfaend = nfa[idx - 1].to;
    int hashcnt = 1;
    for (auto qhash : Q)
    {
        if (qhash.count(nfaend))
        {

            AC.insert(hashcnt);
        }
        else
        {
            NA.insert(hashcnt);
        }

        hashdfa[qhash] = hashcnt;
        hashcnt++;
    }
    for (auto qset : Q)
    {
        for (int i = 0; i < cntop; i++)
        {

            set<int> test = display(qset, ch[i]);
            int xcnt = 0;
            int ycnt = 0;

            if (test.size())
            {

                cout << "{";
                for (auto aqset : qset)
                {
                    xcnt++;
                    if (xcnt == (int)qset.size())
                        cout << aqset;
                    else
                        cout << aqset << ",";
                }
                cout << "}";
                cout << "->" << ch[i];

                gdfa[hashdfa[qset]][ch[i]] = hashdfa[test];

                cout << "{";
                for (auto atest : test)
                {
                    ycnt++;
                    if (ycnt == (int)test.size())
                        cout << atest;
                    else
                        cout << atest << ",";
                }
                cout << "}";
                cout << endl;
            }
        }
    }
    puts("改写合并状态之后");
    for (int i = 1; i <=(int) Q.size(); i++)
    {
        for (int j = 0; j <= (int)ch.size(); j++)
        {
            if (gdfa[i][ch[j]] != -1)
            {
                cout << i << "->" << ch[j] << gdfa[i][ch[j]] << endl;
            }
        }
    }
}
set<set<int>> currentset, finalset;
map<set<int>, int> dfaset;
map<int, int> dfainset;
int num=0;
void buildmap(set<int> &R)
{
    dfaset[R] = ++num;
    for (auto r : R)
    {
        dfainset[r] = num;
    }
}
void mindfa()
{
    buildmap(NA);
    buildmap(AC);
    currentset.insert(AC);
    currentset.insert(NA);
    while (1)
    {

        set<set<int>> newset;
        for (auto C : currentset)
        {
            cout<<"C.size()"<<C.size()<<endl;
            cout<<"current.size()"<<currentset.size()<<endl;
            set<int> first;
            set<int> second;

            for (int i = 0; i < (int)ch.size(); i++)
            {
                set<int> setcnt;
                for (auto c : C)
                {
                    if (gdfa[c][ch[i]] != -1)
                    {
                        setcnt.insert(dfainset[gdfa[c][ch[i]]]);
                    }
                    else
                    {
                        setcnt.insert(dfaset[C]);
                    }
                }
                if (setcnt.size() == 1)
                {
                    continue;
                }
                else
                {
                    cout<<"setcnt.size()"<<setcnt.size()<<endl;
                    int firstsetnum;
                    if (gdfa[*C.begin()][ch[i]] != -1)
                    {
                        firstsetnum = dfainset[gdfa[*C.begin()][ch[i]]];
                    }
                    else
                    {
                        firstsetnum = dfaset[C];
                    }
                    for (auto c : C)
                    {
                        if (gdfa[c][ch[i]] != -1)
                        {
                            if (dfainset[gdfa[c][ch[i]]] == firstsetnum)
                            {
                                first.insert(c);
                            }
                            else
                            {
                                second.insert(c);
                            }
                        }
                        else
                        {
                            if (gdfa[*C.begin()][ch[i]] != -1)
                            {
                                if(dfainset[gdfa[*C.begin()][ch[i]]] == firstsetnum)
                                first.insert(c);
                                else second.insert(c);
                            }
                            else{
                                first.insert(c);
                            }
                        }
                    }
                    newset.insert(first);
                    newset.insert(second);
                    buildmap(first);
                    buildmap(second);
                    break;
                }
            }
            if (first.empty() and second.empty())
                newset.insert(C);
        }
        if (currentset == newset)
        {
            finalset = currentset;
            break;
        }
        else
        {
            currentset = newset;
        }
    }
}

int mingdfa[N][N];
map<set<int>,int> hashmindfa;
int cntmindfa=0;
map<int,set<int>> intoset;
void displaymindfa()
{
    memset(mingdfa,-1,sizeof mingdfa);
    for(auto F:finalset)
    {
        hashmindfa[F]=++cntmindfa;
    }
    for(auto F:finalset)
    {
        for(auto f:F)
        {
            intoset[f]=F;
        }
    }
    for(auto F:finalset)
    {

        for(int j=0;j<(int)ch.size();j++)
        {
            mingdfa[hashmindfa[F]][ch[j]]=hashmindfa[intoset[gdfa[*F.begin()][ch[j]]]];
        }

    }
    puts("最小化DFA图");
    for(int i=1;i<=(int)finalset.size();i++)
    {
        for(int j=0;j<(int)ch.size();j++)
        {
            if(mingdfa[i][ch[j]]!=0)
            cout<<i<<"->"<<ch[j]<<mingdfa[i][ch[j]]<<endl;
        }
    }
}
bool visited[N];

ofstream oscode("../dfatocode.txt");
void Function(int v)
{
    oscode << "               	 	case \'" << v << "\':\n";
    for(int i=0;i<(int)ch.size();i++)
    {
        oscode << "                    		if (ch == \'" << ch[i] << "\') {" << '\n';
        int w=mingdfa[v][ch[i]];
        if(w!=0)
        {
            oscode << "                        		state = \'" << w << "\';\n";
            oscode << "                        		is_accept = " << (w==(int)finalset.size() ? "true" : "false") << ";\n";
            oscode << "                        		break;" << '\n';
        }
        else {
            oscode << "                        		return false;" << '\n';
        }
        oscode << "                    		}" << '\n';
    }
}

void bfs()
{
    memset(visited,false,sizeof visited);
    queue<int> q;
    q.push(startstate);
    visited[startstate]=true;

    while(q.size())
    {
        int t=q.front();
        q.pop();
        Function(t);

        for(int i=0;i<(int)ch.size();i++)
        {
            int w=mingdfa[t][ch[i]];

            if(w!=0 && !visited[w])
            {
                q.push(w);
                visited[w]=true;
            }
        }
    }
    oscode<<endl;
}

void GenerateXLEX() {
    oscode<<"#include<iostream>"<<endl;
    oscode<<"#include<cstring>"<<endl;
    oscode<<"#include<map>"<<endl;
    oscode<<"#include<set>"<<endl;
    oscode<<"using namespace std;"<<endl;
    oscode<<"int main()"<<endl;
    oscode<<"{"<<endl;
    oscode<<"	string str;"<<endl;
    oscode<<"	cin>>str;"<<endl;
    oscode<<"	auto scan=[&](string str)"<<endl;
    oscode<<"	{"<<endl;

    oscode<<"		char state=\'"<<startstate<<"\';"<<endl;
    oscode<<"		bool is_accept=false;"<<endl;
    oscode<<"		for(int i=0;i<str.size();i++)"<<endl;
    oscode<<"		{"<<endl;
    oscode<<"		switch(state)"<<endl;
    oscode<<"		{"<<endl;
                    bfs();
    oscode<<"			default:"<<endl;
    oscode<<"				return false;"<<endl;
    oscode<<"		}"<<endl;
    oscode<<"		}"<<endl;
    oscode<<"			return is_accept;"<<endl;
    oscode<<"	};"<<endl;
    oscode<<"	cout<<str << \"是否可识别：\" << (scan(str) ? \"true\" : \"false\") << endl;"<<endl;
    oscode<<"}"<<endl;
}

void MainWindow:: init()
{
    idx=0;
    memset(nfa,0,sizeof(struct NFA)*N);
    memset(ialpha,false,sizeof ialpha);
    memset(visit,false,sizeof visit);
    memset(visited,false,sizeof visited);
    memset(nfas,'#',sizeof nfas);
    cnt = 1;
    startstate =0;
    cntop=0;
    ch.clear();
    NA.clear();
    AC.clear();
    memset(gdfa,-1,sizeof gdfa);
    hashdfa.clear();
    hashmindfa.clear();
    currentset.clear();
    finalset.clear();
    dfainset.clear();
    dfaset.clear();
    Q.clear();
    num=0;
    memset(mingdfa,0,sizeof mingdfa);
    cntmindfa=0;
    intoset.clear();
}
void MainWindow::on_pushButton_clicked()
{
    init();
    QString text = ui->lineEdit->text();
    std::string res = text.toStdString();
    std::string ans;
    for(int i=0; i<int(res.size()); i++) {
        ans+=res[i];
        if( ((i<int(res.size()))&&  (isalpha(res[i])&&isalpha(res[i+1]))) || (isalpha(res[i])&&res[i+1]=='(') ||(res[i]=='*'&&res[i+1]=='(') || (res[i]==')'&&isdigit(res[i]))|| (res[i]=='*'&&isalpha(res[i+1]))) {
            ans+='.';
        }
    }
    cout << "加入.运算符之后的正则表达式" << ans << endl;
    ans = post(ans);
    cout << "转化为后缀正则表达式" << ans << endl;

    retoNFA(ans);
    ui->tableWidget->clear();

    ui->tableWidget->setRowCount(cnt-1);
    ui->tableWidget->setColumnCount(cnt-1);


    for(int i=1; i<=cnt-1; i++) {
        for(int j=1; j<=cnt-1; j++) {
            if(isalpha(nfas[i][j]))
                ui->tableWidget->setItem(i-1,j-1,new QTableWidgetItem(QString(nfas[i][j])));
            else ui->tableWidget->setItem(i-1,j-1,new QTableWidgetItem("None"));
        }
    }

    nfatodfa();
    printdfa();

    //display_dfa
    ui->tableWidget_2->clear();
    ui->tableWidget_2->setRowCount(Q.size());
    ui->tableWidget_2->setColumnCount(ch.size());

    QStringList header;
    for(int i=0;i<(int)ch.size();i++)
    {
        QString temp="";
        temp+=ch[i];
        header<<temp;
    }

    ui->tableWidget_2->setHorizontalHeaderLabels(header);

    for(int i=1; i<=int(Q.size()); i++) {
        for(int j=0; j< int(ch.size()); j++) {
            if(gdfa[i][ch[j]]!=-1)
                ui->tableWidget_2->setItem(i-1,j,new QTableWidgetItem(QString::number(gdfa[i][ch[j]])));
            else ui->tableWidget_2->setItem(i-1,j,new QTableWidgetItem("None"));
        }
    }

    mindfa();
    displaymindfa();

    ui->tableWidget_3->clear();
    ui->tableWidget_3->setRowCount(finalset.size());
    ui->tableWidget_3->setColumnCount(ch.size());
    ui->tableWidget_3->setHorizontalHeaderLabels(header);

    for(int i=1;i<=int(finalset.size());i++)
    {
        for(int j=0;j<=int(ch.size());j++)
        if(mingdfa[i][ch[j]]!=0)
        {
            ui->tableWidget_3->setItem(i-1,j,new QTableWidgetItem(QString::number(mingdfa[i][ch[j]])));
        }
        else ui->tableWidget_3->setItem(i-1,j,new QTableWidgetItem("None"));
    }
    GenerateXLEX();
    ui->textEdit->clear();
    ifstream ifile("../dfatocode.txt");
    string item;
    string tempstr;
    getline(ifile,item);
    while(ifile)
    {
        tempstr+=item+'\n';
        getline(ifile,item);
    }

    ui->textEdit->insertPlainText(QString::fromStdString(tempstr));
    fstream file("../dfatocode.txt", ios::out);
}


void MainWindow::on_pushButton_2_clicked()
{
    std::ofstream out("../re.txt");
    QString text = ui->lineEdit->text();
    std::string s = text.toStdString();
    out<<s;

    std::ofstream out2("../xlexcode.txt");
    QString xlexcode = ui->textEdit->document()->toPlainText();
    std::string xlexs = xlexcode.toStdString();
    out2<<xlexs;

    out.close();
    out2.close();
}


void MainWindow::on_pushButton_3_clicked()
{
    //定义路径
    QString path;
    path=QFileDialog ::getOpenFileName(this,
                                              "open","../","TXT(*.txt)");
     if(path.isEmpty()==false)
     {
         //文件对象
         QFile file(path);

         //打开文件，只读方式
         bool isok=file.open(QIODevice::ReadOnly);

         if(isok)
         {
             //读文件，默认识别utf8编码
             QByteArray array= file.readAll();

             //显示到编辑区
             ui->lineEdit->setText(array);
         }
         //关闭文件
         file.close();
     }
}
