/*    a(b|c)*   */
/* (a|b)*abb   */
#include <bits/stdc++.h>
using namespace std;

bool isdigitoralpha(char s)
{
	if (isdigit(s) || isalpha(s))
		return true;
	return false;
}
int priority(char s)
{
	switch (s)
	{
	case '*':
		return 4;
	case '.':
		return 3;
	case '|':
		return 2;
	default:
		return 1;
	}
}
string post(string &x)
{
	string output;
	stack<char> s;
	int j = 0;
	for (int i = 0; i < x.size(); i++)
	{
		if (isdigitoralpha(x[i]))
		{
			output += x[i];
		}
		else if(x[i]=='(' || x[i]=='.')
		{
			s.push(x[i]);
		}
		else if(x[i]==')')
		{
			while(s.top()!='(')
			{
				output+=s.top();
				s.pop();
			}
			s.pop();
		}
		else if(x[i]=='|')
		{
			while (!s.empty() and s.top() != '(') {
                    output += s.top();
                    s.pop();
            }
            s.push(x[i]);
		}
		else {
			while (!s.empty() and s.top() != '(' and s.top() != '|' and s.top() != '.') {
                    output += s.top();
                    s.pop();
            }
            output += x[i];
		}
	}
	while (!s.empty())
	{
		output += s.top();
		s.pop();
	}
	return output;
}

string res;
string ans;
void init()
{
	//cin>>res;
	res = "a(b|c)*";
	//res = "(a|b)*abb";
	for (int i = 0; i < res.size(); i++)
	{
		ans += res[i];
		if (i < res.size() && (isalpha(res[i]) && isalpha(res[i + 1])) || (isalpha(res[i]) && res[i + 1] == '(') || (res[i] == '*' && res[i + 1] == '(') || (res[i] == ')' && isdigit(res[i])) || (res[i] == '*' && isalpha(res[i + 1])))
		{
			ans += '.';
		}
	}
	cout << "加入.运算符之后的正则表达式" << ans << endl;
	ans = post(ans);
	cout << "转化为后缀正则表达式" << ans << endl;
}

//NFA有关的全局变量
const int N = 261;
int idx = 0;
struct NFA
{
	int from;
	int to;
	char edge;
} nfa[N];
char nfas[N][N]; //nfa 有一对多的情况 所以只能使用 点-点 的邻接矩阵

int cnt = 1;
int startstate =0;

//出现的字符
bool ialpha[1000];
int cntop;
vector<char> ch;

void retoNFA(string &s)
{
	//后缀正则表达式转NFA
	stack<NFA> st;
	for (int i = 0; i < s.size(); i++)
	{
		if (isdigitoralpha(s[i]))
		{
			if (ialpha[s[i] - '0'] == false)
			{
				ialpha[s[i] - '0'] = true;
				ch.push_back(s[i]);
				cntop++;
			}
			if(startstate==0) startstate=cnt;
			nfa[idx].from = cnt++;
			nfa[idx].to = cnt++;
			nfa[idx].edge = s[i];
			nfas[nfa[idx].from][nfa[idx].to] = s[i];
			st.push(nfa[idx++]);
		}
		if (s[i] == '|')
		{
			nfa[idx].from = cnt++;
			nfa[idx].to = cnt++;

			NFA s1 = st.top();
			st.pop();
			NFA s2 = st.top();
			st.pop();

			nfas[nfa[idx].from][s1.from] = 'e';
			nfas[nfa[idx].from][s2.from] = 'e';

			nfas[s1.to][nfa[idx].to] = 'e';
			nfas[s2.to][nfa[idx].to] = 'e';

			st.push(nfa[idx++]);
		}
		if (s[i] == '*')
		{
			nfa[idx].from = cnt++;
			nfa[idx].to = cnt++;

			NFA s1 = st.top();
			st.pop();

			nfas[nfa[idx].from][s1.from] = 'e';
			nfas[s1.to][nfa[idx].to] = 'e';
			nfas[s1.to][s1.from] = 'e';
			nfas[nfa[idx].from][nfa[idx].to] = 'e';

			st.push(nfa[idx++]);
		}
		if (s[i] == '.')
		{
			NFA s1 = st.top();
			st.pop();

			NFA s2 = st.top();
			st.pop();

			nfa[idx].from = s2.from;
			nfa[idx].to = s1.to;

			nfas[s2.to][s1.from] = 'e';

			st.push(nfa[idx++]);
		}
	}

	//输出NFA图
	for (int i = 1; i <= cnt - 1; i++)
	{
		for (int j = 1; j <= cnt - 1; j++)
		{
			if (isalpha(nfas[i][j]))
				cout << i << "->" << j << ":" << nfas[i][j] << " ";
			// else cout<<i<<"->"<<j<<":none"<<" ";
		}
		cout << endl;
	}
}

set<int> delta(set<int> x, char c)
{
	set<int> temp;
	for (auto X : x)
	{
		for (int j = 1; j <= cnt - 1; j++)
		{
			if (nfas[X][j] == c)
				temp.insert(j);
		}
	}
	return temp;
}

bool visit[N];
set<int> eclosure(set<int> x)
{
	memset(visit, false, sizeof visit);
	set<int> closure;

	queue<int> q;

	for (auto X : x)
		q.push(X);

	while (q.size())
	{
		int t = q.front();
		q.pop();
		closure.insert(t);
		for (int j = 1; j <= cnt - 1; j++)
		{
			if (nfas[t][j] == 'e')
			{
				if (!visit[j])
				{
					q.push(j);
					visit[j] = true;
				}
			}
		}
	}
	return closure;
}
set<set<int>> Q;
void nfatodfa()
{

	int nfastart = nfa[idx - 1].from;
	int nfaend = nfa[idx - 1].to;

	set<int> q = eclosure({nfastart});
	Q.insert(q);

	queue<set<int>> worklist;
	worklist.push(q);

	while (worklist.size())
	{

		auto t = worklist.front();
		worklist.pop();

		for (int i = 0; i < cntop; i++)
		{
			set<int> T = eclosure(delta(t, ch[i]));

			if (!Q.count(T) && T.size())
			{
				Q.insert(T);
				worklist.push(T);
			}
		}
	}
}

set<int> display(set<int> aset, char c)
{
	return eclosure(delta(aset, c));
}

set<int> NA;
set<int> AC;
int gdfa[N][N];
map<set<int>, int> hashdfa;
void printdfa()
{
	memset(gdfa, -1, sizeof gdfa);
	int nfastart = nfa[idx - 1].from;
	int nfaend = nfa[idx - 1].to;
	int hashcnt = 1;
	for (auto qhash : Q)
	{
		if (qhash.count(nfaend))
		{

			AC.insert(hashcnt);
		}
		else
		{
			NA.insert(hashcnt);
		}

		hashdfa[qhash] = hashcnt;
		hashcnt++;
	}
	for (auto qset : Q)
	{
		for (int i = 0; i < cntop; i++)
		{

			set<int> test = display(qset, ch[i]);
			int xcnt = 0;
			int ycnt = 0;

			if (test.size())
			{

				cout << "{";
				for (auto aqset : qset)
				{
					xcnt++;
					if (xcnt == qset.size())
						cout << aqset;
					else
						cout << aqset << ",";
				}
				cout << "}";
				cout << "->" << ch[i];

				gdfa[hashdfa[qset]][ch[i]] = hashdfa[test];

				cout << "{";
				for (auto atest : test)
				{
					ycnt++;
					if (ycnt == test.size())
						cout << atest;
					else
						cout << atest << ",";
				}
				cout << "}";
				cout << endl;
			}
		}
	}
	puts("改写合并状态之后");
	for (int i = 1; i <= Q.size(); i++)
	{
		for (int j = 0; j <= ch.size(); j++)
		{
			if (gdfa[i][ch[j]] != -1)
			{
				cout << i << "->" << ch[j] << gdfa[i][ch[j]] << endl;
			}
		}
	}
}

set<set<int>> currentset, finalset;	
map<set<int>, int> dfaset;
map<int, int> dfainset;
int num=0;
void buildmap(set<int> &R)
{
	dfaset[R] = ++num;
	for (auto r : R)
	{
		dfainset[r] = num;
	}
}
void mindfa()
{
	buildmap(NA);
	buildmap(AC);
	currentset.insert(AC);
	currentset.insert(NA);
	while (1)
	{

		set<set<int>> newset;
		for (auto C : currentset)
		{
			//cout<<"C.size()"<<C.size()<<endl;
			//cout<<"current.size()"<<currentset.size()<<endl;
			set<int> first;
			set<int> second;

			for (int i = 0; i < ch.size(); i++)
			{
				set<int> setcnt;
				for (auto c : C)
				{
					if (gdfa[c][ch[i]] != -1)
					{
						setcnt.insert(dfainset[gdfa[c][ch[i]]]);
					}
					else
					{
						setcnt.insert(dfaset[C]);
					}	
				}
				if (setcnt.size() == 1)
				{
					continue;
				}
				else
				{
					cout<<"setcnt.size()"<<setcnt.size()<<endl;
					int firstsetnum;
					if (gdfa[*C.begin()][ch[i]] != -1)
					{
						firstsetnum = dfainset[gdfa[*C.begin()][ch[i]]];
					}
					else
					{
						firstsetnum = dfaset[C];
					}
					for (auto c : C)
					{
						if (gdfa[c][ch[i]] != -1)
						{
							if (dfainset[gdfa[c][ch[i]]] == firstsetnum)
							{
								first.insert(c);
							}
							else
							{
								second.insert(c);
							}
						}
						else
						{
							if (gdfa[*C.begin()][ch[i]] != -1)
							{
								if(dfainset[gdfa[*C.begin()][ch[i]]] == firstsetnum)
								first.insert(c);
								else second.insert(c);
							}
							else{
								first.insert(c);
							}		
						}
					}
					newset.insert(first);
					newset.insert(second);
					buildmap(first);
					buildmap(second);
					break;
				}
			}
			if (first.empty() and second.empty())
				newset.insert(C);
		}
		if (currentset == newset)
		{
			finalset = currentset;
			break;
		}
		else
		{
			currentset = newset;
		}
	}
}

int mingdfa[N][N];
map<set<int>,int> hashmindfa;
int cntmindfa=0;
map<int,set<int>> intoset;
void displaymindfa()
{
	memset(mingdfa,0,sizeof mingdfa);
	for(auto F:finalset)
	{
		hashmindfa[F]=++cntmindfa;
	}
	for(auto F:finalset)
	{
		for(auto f:F)
		{
			intoset[f]=F;
		}
	}
	for(auto F:finalset)
	{

		for(int j=0;j<ch.size();j++)
		{
			mingdfa[hashmindfa[F]][ch[j]]=hashmindfa[intoset[gdfa[*F.begin()][ch[j]]]];
		}
		
	}
	puts("最小化DFA图");
	for(int i=1;i<=finalset.size();i++)
	{
		for(int j=0;j<ch.size();j++)
		{
			if(mingdfa[i][ch[j]]!=0)
			cout<<i<<"->"<<ch[j]<<mingdfa[i][ch[j]]<<endl;
		}
	}
}
bool visited[N];

void Function(int v)
{
    cout << "               	 	case \'" << v << "\':\n";
    for(int i=0;i<ch.size();i++)
    {
        cout << "                    		if (ch == \'" << ch[i] << "\') {" << '\n';
        int w=mingdfa[v][ch[i]];
        if(w!=0) 
        {
            cout << "                        		state = \'" << w << "\';\n";
            cout << "                        		is_accept = " << (w==finalset.size() ? "true" : "false") << ";\n";
            cout << "                        		break;" << '\n';            
        }
        else {
            cout << "                        		return false;" << '\n';              
        }
        cout << "                    		}" << '\n'; 
    }
}

void bfs()
{
    memset(visited,false,sizeof visited);
    queue<int> q;
    q.push(startstate);
    visited[startstate]=true;

    while(q.size())
    {
        int t=q.front();
        q.pop();
        Function(t);

        for(int i=0;i<ch.size();i++)
        {
            int w=mingdfa[t][ch[i]];

            if(w!=0 && !visited[w])
            {
                q.push(w);
                visited[w]=true;
            }
        }
    }
    cout<<endl;
}

void GenerateXLEX() {
	cout<<"#include<iostream>"<<endl;
	cout<<"#include<cstring>"<<endl;
	cout<<"#include<map>"<<endl;
	cout<<"#include<set>"<<endl;
	cout<<"using namespace std;"<<endl;
	cout<<"int main()"<<endl;
	cout<<"{"<<endl;
	cout<<"	string str;"<<endl;
	cout<<"	cin>>str;"<<endl;
	cout<<"	auto scan=[&](string str)"<<endl;
	cout<<"	{"<<endl;

	cout<<"		char state=\'"<<startstate<<"\';"<<endl;
	cout<<"		bool is_accept=false;"<<endl;
	cout<<"		for(int i=0;i<str.size();i++)"<<endl;
	cout<<"		{"<<endl;
	cout<<"		switch(state)"<<endl;
	cout<<"		{"<<endl;
					bfs();
	cout<<"			default:"<<endl;
	cout<<"				return false;"<<endl;
	cout<<"		}"<<endl;
	cout<<"		}"<<endl;
	cout<<"			return is_accept;"<<endl;
	cout<<"	};"<<endl;
	cout<<"	cout<<str << \"是否可识别：\" << (scan(str) ? \"true\" : \"false\") << endl;"<<endl;
	cout<<"}"<<endl;
}
int main()
{
	init();
	retoNFA(ans);
	nfatodfa();
	printdfa();
	mindfa();
	displaymindfa();
	GenerateXLEX();
}
