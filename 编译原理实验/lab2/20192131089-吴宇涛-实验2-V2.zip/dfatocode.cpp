/*
(a|b)*abb
*/
//https://blog.csdn.net/charles_zhang_ng/article/details/53302955  C++字符串读写

#include<bits/stdc++.h>
using namespace std;
const int N=260;

int startstate=1;
int endstate=4;
vector<char> cntchar={'a','b'};



int table[N][N];
bool visited[N];

void Function(int v)
{
    cout << "                case \'" << v << "\':\n";
    for(int i=0;i<cntchar.size();i++)
    {
        cout << "                    if (ch == \'" << cntchar[i] << "\') {" << '\n';
        int w=table[v][cntchar[i]];
        if(w!=-1) 
        {
            cout << "                        state = \'" << w << "\';\n";
            cout << "                        is_accept = " << (w==endstate ? "true" : "false") << ";\n";
            cout << "                        break;" << '\n';            
        }
        else {
            cout << "                        return false;" << '\n';              
        }
        cout << "                    }" << '\n'; 
    }
}

void bfs()
{
    memset(visited,false,sizeof visited);
    queue<int> q;
    q.push(startstate);
    visited[startstate]=true;

    while(q.size())
    {
        int t=q.front();
        q.pop();
        Function(t);

        for(int i=0;i<cntchar.size();i++)
        {
            int w=table[t][cntchar[i]];

            if(w!=-1 && !visited[w])
            {
                q.push(w);
                visited[w]=true;
            }
        }
    }
    cout<<endl;
}

void GenerateXLEX() {
    std::cout << "#include <iostream>" << '\n';
    std::cout << "#include <cstring>" << '\n';
    std::cout << "#include <functional>" << '\n';
    std::cout << '\n';
    std::cout << "int main() {" << '\n';
    std::cout << "    std::string str;" << '\n';
    std::cout << "    std::cin >> str;" << '\n';
    std::cout << "    auto scan = [&](std::string str) {" << '\n';
    std::cout << "        char state = \'" << startstate << "\';\n";
    std::cout << "        bool is_accept = false;" << '\n';
    std::cout << "        for (auto ch : str) {" << '\n';
    std::cout << "            switch (state) {" << '\n';
    bfs();
    std::cout << "                default:" << '\n';
    std::cout << "                    return false;" << '\n';
    std::cout << "             }" << '\n';
    std::cout << "        }" << '\n';
    std::cout << "        return is_accept;" << '\n';
    std::cout << "    };" << '\n';
    std::cout << "    std::cout << str << \"是否可识别：\" << (scan(str) ? \"true\" : \"false\") << std::endl;" << '\n';
    std::cout << "}" << '\n';
}


int main()
{
    memset(table,-1,sizeof table);
    table[1]['b']=1;
    table[1]['a']=2;
    table[2]['a']=2;
    table[2]['b']=3;
    table[3]['a']=2;
    table[3]['b']=4;
    table[4]['a']=2;
    table[4]['b']=1;
    GenerateXLEX();
}
